import { Component, OnInit } from '@angular/core';
import { NgStyle } from '@angular/common';

@Component({
  selector: 'app-output-event-emitter-parent',
  templateUrl: './output-event-emitter-parent.component.html',
  styleUrls: ['./output-event-emitter-parent.component.scss']
})
export class OutputEventEmitterParentComponent implements OnInit {
  exampleParent : any;

  constructor() { }

  ngOnInit() {
  }
  exampleMethodParent($event){
    debugger;
    this.exampleParent = $event;
  }

}
