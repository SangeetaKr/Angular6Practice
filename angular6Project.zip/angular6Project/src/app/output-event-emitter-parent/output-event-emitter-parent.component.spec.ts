import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OutputEventEmitterParentComponent } from './output-event-emitter-parent.component';

describe('OutputEventEmitterParentComponent', () => {
  let component: OutputEventEmitterParentComponent;
  let fixture: ComponentFixture<OutputEventEmitterParentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OutputEventEmitterParentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OutputEventEmitterParentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
