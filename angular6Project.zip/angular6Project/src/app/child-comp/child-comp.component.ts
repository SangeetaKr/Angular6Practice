import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-child-comp',
  templateUrl: './child-comp.component.html',
  styleUrls: ['./child-comp.component.scss']
})
export class ChildCompComponent implements OnInit {

  @Input() childMessage: string;
  constructor() { }

  ngOnInit() {
    console.log(this.childMessage);
  };


}
