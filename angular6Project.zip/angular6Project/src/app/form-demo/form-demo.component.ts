import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms'; 

@Component({
  selector: 'app-form-demo',
  templateUrl: './form-demo.component.html',
  styleUrls: ['./form-demo.component.scss']
})
export class FormDemoComponent implements OnInit {
  model: any = {};

  constructor() {
  }

  ngOnInit() {
  }
  
  Register(regForm:NgForm){ 
    debugger; 
    console.log(regForm);        
  }  

  onSubmit(){
    debugger;
    var obj = this.model;

  }
  myFormSubmit(){
    debugger;
    var aa = this.model;
  }

}
