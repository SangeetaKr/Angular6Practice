import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
//import { RouterModule, Routes } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { OutputEventEmitterChildComponent } from './output-event-emitter-child/output-event-emitter-child.component';
import { OutputEventEmitterParentComponent } from './output-event-emitter-parent/output-event-emitter-parent.component';
import { ViewChildChildrenComponent } from './view-child-children/view-child-children.component';
import { ViewChildParentComponent } from './view-child-parent/view-child-parent.component';
import { FormDemoComponent } from './form-demo/form-demo.component';
//import { FormsModule } from '@angular/forms';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ModelDrivenFormsDemoComponent } from './model-driven-forms-demo/model-driven-forms-demo.component'
import {UserService} from './model-driven-forms-demo/user-service';
import { EventsBindingsComponent } from './events-bindings/events-bindings.component';
import { DirectiveDemoComponent } from './directive-demo/directive-demo.component';
import { DirectiveDemoDirective } from './directive-demo.directive';
import { ParentCompComponent } from './parent-comp/parent-comp.component';
import { ChildCompComponent } from './child-comp/child-comp.component';
import { ChildTwoComponent } from './child-two/child-two.component';
import { ParentTwoComponent } from './parent-two/parent-two.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { ObservableDemoComponent } from './observable-demo/observable-demo.component';

@NgModule({
  declarations: [
    AppComponent,
    OutputEventEmitterChildComponent,
    OutputEventEmitterParentComponent,
    ViewChildChildrenComponent,
    ViewChildParentComponent,
    FormDemoComponent,
    ModelDrivenFormsDemoComponent,
    EventsBindingsComponent,
    DirectiveDemoComponent,
    DirectiveDemoDirective,
    ParentCompComponent,
    ChildCompComponent,
    ChildTwoComponent,
    ParentTwoComponent,
    PageNotFoundComponent,
    ObservableDemoComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
