import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-child-two',
  templateUrl: './child-two.component.html',
  styleUrls: ['./child-two.component.scss']
})
export class ChildTwoComponent implements OnInit {
  @Output() public dataFromChildToParent = new EventEmitter<string>();
  sentDataToParentUsingViewChild: any = 'data from child two to parent using viewChild';
  constructor() { }

  ngOnInit() {
  };

  sentTextToParent(data) {
    debugger;
    this.dataFromChildToParent.emit(data);
  };

}
