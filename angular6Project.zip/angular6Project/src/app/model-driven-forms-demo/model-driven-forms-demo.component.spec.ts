import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModelDrivenFormsDemoComponent } from './model-driven-forms-demo.component';

describe('ModelDrivenFormsDemoComponent', () => {
  let component: ModelDrivenFormsDemoComponent;
  let fixture: ComponentFixture<ModelDrivenFormsDemoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModelDrivenFormsDemoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModelDrivenFormsDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
