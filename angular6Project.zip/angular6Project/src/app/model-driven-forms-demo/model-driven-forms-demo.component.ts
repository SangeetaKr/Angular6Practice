import { Component, OnInit } from '@angular/core';
//import { FormBuilder, FormGroup, Validator, ReactiveFormsModule } from '@angular/forms';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { UserService } from './user-service';
import { User } from './user';
import { Profile } from './profile';

@Component({
  selector: 'app-model-driven-forms-demo',
  templateUrl: './model-driven-forms-demo.component.html',
  styleUrls: ['./model-driven-forms-demo.component.scss']
})
export class ModelDrivenFormsDemoComponent implements OnInit {

  isValidFormSubmitted = null;
  user = new User();
  allProfiles: Profile[];

  userForm = new FormGroup({
    userName: new FormControl('', [Validators.required, Validators.minLength(5)]),
    gender: new FormControl('', Validators.required),
    profile: new FormControl('', Validators.required),
    isTCAccepted: new FormControl('', Validators.requiredTrue)
  });

  constructor(private userService: UserService) { }


  ngOnInit() {
    this.allProfiles = this.userService.getPofiles();
  }

  onFormSubmit() {
    //debugger;
    this.isValidFormSubmitted = false;
    if (this.userForm.invalid) {
      return;
    }
    this.isValidFormSubmitted = true;
    this.user = this.userForm.value;
    this.userService.createUser(this.user);
    this.userForm.reset();
  }

  get userName() {
    //debugger;
    return this.userForm.get('userName');
  }
  get gender() {
    //debugger;
    return this.userForm.get('gender');
  }
  get profile() {
    //debugger;
    return this.userForm.get('profile');
  }
  get isTCAccepted() {
    //debugger;
    return this.userForm.get('isTCAccepted');
  }



}
