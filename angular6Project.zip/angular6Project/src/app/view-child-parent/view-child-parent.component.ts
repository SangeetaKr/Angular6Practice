import { Component, OnInit, ViewChild } from '@angular/core';
import { ViewChildChildrenComponent } from '../view-child-children/view-child-children.component'

@Component({
  selector: 'app-view-child-parent',
  templateUrl: './view-child-parent.component.html',
  styleUrls: ['./view-child-parent.component.scss']
})
export class ViewChildParentComponent implements OnInit {
  @ViewChild(ViewChildChildrenComponent) childReference;

  constructor() { }

  ngOnInit() {
  }

}
