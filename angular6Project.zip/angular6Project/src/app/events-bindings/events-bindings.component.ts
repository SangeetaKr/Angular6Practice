import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { debug } from 'util';

@Component({
  selector: 'app-events-bindings',
  templateUrl: './events-bindings.component.html',
  styleUrls: ['./events-bindings.component.scss']
})
export class EventsBindingsComponent implements OnInit {

  model: any;
  copies: string = "My name is san";
  cutterText: string = "cut this text";
  @Output() eventEmitterCut = new EventEmitter();

  constructor() { }

  ngOnInit() {
  }

  clickFunction() {
    console.log('button clicked');
  };

  dblClickFunction() {
    console.log('button double clicked');
  };

  blurFunction() {
    console.log('blur on clicking outside the textbox');
  };

  pasteUrlFunction(evnt) {
    console.log(evnt);
  };

  copyUrlFunction(evt) {
    console.log(evt);
  };

  // cutFunction(event){
  //   debugger;
  //   this.eventEmitterCut.emit(event);
  // }

  keyUpFunction(evnt, data) {
    console.log(data);
  };

  keyPressFunction(evnt) {
    console.log(evnt);
  };

  keyDownFunction(evnt) {
    alert(evnt + '-is pressed');
  };

  mouseUpFunction(evnt) {
    console.log(evnt.type);
  };

  mouseDownFunction(evnt) {
    console.log(evnt.type);
  };

  mouseEnterFunction(evnt) {
    console.log(evnt.type);
  };

  focusFunction(){
  };

  focusOutFunction(){
  };

  allowDrop(ev) {
    debugger;
    ev.preventDefault();
  }

  drag(ev) {
    debugger;
    ev.dataTransfer.setData("text", ev.target.id);
  }

  drop(ev) {
    debugger;
    ev.preventDefault();
    var data = ev.dataTransfer.getData("text");
    ev.target.appendChild(document.getElementById(data));
  }

}
