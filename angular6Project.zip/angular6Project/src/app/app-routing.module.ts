import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OutputEventEmitterParentComponent } from './output-event-emitter-parent/output-event-emitter-parent.component';
import { FormDemoComponent } from './form-demo/form-demo.component'
import { ModelDrivenFormsDemoComponent } from './model-driven-forms-demo/model-driven-forms-demo.component';
import { EventsBindingsComponent } from './events-bindings/events-bindings.component';
import { DirectiveDemoComponent } from './directive-demo/directive-demo.component';
import { AppComponent } from './app.component';
import { ParentCompComponent } from './parent-comp/parent-comp.component';
import { ChildCompComponent } from './child-comp/child-comp.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { ObservableDemoComponent } from './observable-demo/observable-demo.component';

const appRoutes: Routes = [
  { path: '', component: AppComponent },
  { path: 'parent-output-emitter', component: OutputEventEmitterParentComponent },
  { path: 'template-form-demo', component: FormDemoComponent },
  { path: 'model-driven-from-demo', component: ModelDrivenFormsDemoComponent },
  { path: 'events-bindings', component: EventsBindingsComponent },
  { path: 'directive-demo', component: DirectiveDemoComponent },
  { path: 'parent-comp', component: ParentCompComponent },
  { path: 'child-comp', component: ChildCompComponent },
  { path: 'observDemo', component: ObservableDemoComponent },
  { path: '', redirectTo: '', pathMatch: 'full' },
  { path: '**', component: PageNotFoundComponent }
];

@NgModule({
  imports: [
    RouterModule.forRoot(
      appRoutes,
      { enableTracing: false } // <-- debugging purposes only
    )
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule { }
