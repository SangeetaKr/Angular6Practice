import { DirectiveDemoDirective } from './directive-demo.directive';

describe('DirectiveDemoDirective', () => {
  it('should create an instance', () => {
    const directive = new DirectiveDemoDirective();
    expect(directive).toBeTruthy();
  });
});
