import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ChildTwoComponent } from "../child-two/child-two.component";


@Component({
  selector: 'app-parent-comp',
  templateUrl: './parent-comp.component.html',
  styleUrls: ['./parent-comp.component.scss']
})
export class ParentCompComponent implements OnInit {

  parentMessage: any = '';
  childTwoMessage: any = '';
  @ViewChild(ChildTwoComponent) child;
  childMessageUsingViewChild: any;

  constructor() { }

  ngOnInit() {
  }

  sentTextToChild(data) {
    this.parentMessage = data;
  };

  dataFromChildTwoToParent(dataFromChild) {
    this.childTwoMessage = dataFromChild;
  };

  ngAfterViewInit() {
    debugger
    this.childMessageUsingViewChild = this.child.sentDataToParentUsingViewChild;
  }

}
