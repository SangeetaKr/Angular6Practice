import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-directive-demo',
  templateUrl: './directive-demo.component.html',
  styleUrls: ['./directive-demo.component.scss']
})
export class DirectiveDemoComponent implements OnInit {

  heroes: any = [];
  typeOfInput: any = 'red';
  //typeOfInput:any='green';   //change to see ngSwitch example
  showHideData: boolean = true;
  
  constructor() { }

  ngOnInit() {
    this.heroes = [
      { id: 1, name: 'Superman' },
      { id: 2, name: 'Batman' },
      { id: 5, name: 'BatGirl' },
      { id: 3, name: 'Robin' },
      { id: 4, name: 'Flash' }
    ];
  };

  trackHero(index, heroObj) {
    console.log(index + '-' + heroObj.name);
  }

}
