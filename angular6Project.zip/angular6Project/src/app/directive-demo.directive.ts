import { Directive, ElementRef, Input, OnInit, Renderer } from '@angular/core';

@Directive({
  selector: '[firstDirective]'
})
export class DirectiveDemoDirective implements OnInit {
  @Input() showHide: string;
  constructor(public el: ElementRef, public renderer: Renderer) {
    el.nativeElement.style.color = 'red';
    
  }

  ngOnInit() {
    if (this.showHide) {
      this.renderer.setElementStyle(this.el.nativeElement, 'display', 'none');
    }
  }

}
