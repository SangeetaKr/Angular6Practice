import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-child-children',
  templateUrl: './view-child-children.component.html',
  styleUrls: ['./view-child-children.component.scss']
})
export class ViewChildChildrenComponent implements OnInit {

  exampleChild:any = "Data from view child";
  constructor() { }

  ngOnInit() {
  }

}
