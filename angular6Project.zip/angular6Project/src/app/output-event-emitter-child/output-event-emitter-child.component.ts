import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-output-event-emitter-child',
  templateUrl: './output-event-emitter-child.component.html',
  styleUrls: ['./output-event-emitter-child.component.scss']
})
export class OutputEventEmitterChildComponent implements OnInit {

  @Output() exampleOutput = new EventEmitter<string>();
  exampleChild: any = "data from child to parent";
  constructor() { }

  ngOnInit() {}
  
  exampleMethodChild() {
    debugger;
    this.exampleOutput.emit(this.exampleChild);
  }

}
