import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OutputEventEmitterChildComponent } from './output-event-emitter-child.component';

describe('OutputEventEmitterChildComponent', () => {
  let component: OutputEventEmitterChildComponent;
  let fixture: ComponentFixture<OutputEventEmitterChildComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OutputEventEmitterChildComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OutputEventEmitterChildComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
